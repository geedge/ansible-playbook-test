#!/bin/bash

base_dir=loacl

if [ -f "$base_dir/kafka-manager-1.3.3.18/RUNNING_PID" ]; then 
 rm -rf $base_dir/kafka-manager-1.3.3.18/RUNNING_PID
fi

nohup $base_dir/kafka-manager-1.3.3.18/bin/kafka-manager -Dconfig.file=$base_dir/kafka-manager-1.3.3.18/conf/application.conf > /dev/null 2>&1 &
