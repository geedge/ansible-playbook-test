#!/bin/sh

IP_LIST='10.4.35.7:9092,10.4.35.8:9092,10.4.35.9:9092,10.4.35.10:9092,10.4.35.11:9092'

/home/tsg/galaxy/kafka_2.11-1.0.0/bin/kafka-console-producer.sh '--broker-list' $IP_LIST '--topic' POLICY-EVENT-LOG < POLICY-EVENT-LOG
/home/tsg/galaxy/kafka_2.11-1.0.0/bin/kafka-console-producer.sh '--broker-list' $IP_LIST '--topic' RADIUS-LOG < RADIUS-LOG
/home/tsg/galaxy/kafka_2.11-1.0.0/bin/kafka-console-producer.sh '--broker-list' $IP_LIST '--topic' SESSION-RECORD-LOG < SESSION-RECORD-LOG
/home/tsg/galaxy/kafka_2.11-1.0.0/bin/kafka-console-producer.sh '--broker-list' $IP_LIST '--topic' TOP-EXTERNAL-HOST-LOG < TOP-EXTERNAL-HOST-LOG
/home/tsg/galaxy/kafka_2.11-1.0.0/bin/kafka-console-producer.sh '--broker-list' $IP_LIST '--topic' TOP-INTERNAL-HOST-LOG < TOP-INTERNAL-HOST-LOG
/home/tsg/galaxy/kafka_2.11-1.0.0/bin/kafka-console-producer.sh '--broker-list' $IP_LIST '--topic' TOP-URLS-LOG < TOP-URLS-LOG
/home/tsg/galaxy/kafka_2.11-1.0.0/bin/kafka-console-producer.sh '--broker-list' $IP_LIST '--topic' TOP-USER-LOG < TOP-USER-LOG
/home/tsg/galaxy/kafka_2.11-1.0.0/bin/kafka-console-producer.sh '--broker-list' $IP_LIST '--topic' TOP-WEBSITE-DOMAIN-LOG < TOP-WEBSITE-DOMAIN-LOG
/home/tsg/galaxy/kafka_2.11-1.0.0/bin/kafka-console-producer.sh '--broker-list' $IP_LIST '--topic' TRAFFIC-METRICS-LOG < TRAFFIC-METRICS-LOG
