<!--
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
-->

1) This lock interface recipe implements the lock recipe
mentioned in ../../../docs/recipes.[html,pdf].

2) To compile the lock java recipe you can just run ant jar from 
this directory. For compiling the c libarary go to src/c and read
the INSTALLATION instructions. 
Please report any bugs on the jira 

http://issues.apache.org/jira/browse/ZOOKEEPER

  
